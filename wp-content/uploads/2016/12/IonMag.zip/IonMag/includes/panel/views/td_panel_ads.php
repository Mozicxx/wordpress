<?php

td_api_ad::helper_display_ads();