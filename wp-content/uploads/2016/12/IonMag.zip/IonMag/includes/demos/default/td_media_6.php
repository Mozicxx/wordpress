<?php
/**
 * Created by ra on 6/13/2015.
 */

//single images
td_demo_media::add_image_to_media_gallery('td_pic_sport1',                "http://demo_content.tagdiv.com/ion_mag/default/sport1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_sport2',                "http://demo_content.tagdiv.com/ion_mag/default/sport2.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_sport3',                "http://demo_content.tagdiv.com/ion_mag/default/sport3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_sport4',                "http://demo_content.tagdiv.com/ion_mag/default/sport4.jpg");

td_demo_media::add_image_to_media_gallery('td_pic_travel1',                "http://demo_content.tagdiv.com/ion_mag/default/travel1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_travel2',                "http://demo_content.tagdiv.com/ion_mag/default/travel2.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_travel3',                "http://demo_content.tagdiv.com/ion_mag/default/travel3.jpg");