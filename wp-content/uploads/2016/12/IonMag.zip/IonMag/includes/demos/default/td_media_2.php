<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_7',                   "http://demo_content.tagdiv.com/ion_mag/default/7.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_8',                   "http://demo_content.tagdiv.com/ion_mag/default/8.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_9',                   "http://demo_content.tagdiv.com/ion_mag/default/9.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_10',                  "http://demo_content.tagdiv.com/ion_mag/default/10.jpg");

//post images
td_demo_media::add_image_to_media_gallery('td_pic_p1',                  "http://demo_content.tagdiv.com/ion_mag/default/p1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p2',                  "http://demo_content.tagdiv.com/ion_mag/default/p2.jpg");
