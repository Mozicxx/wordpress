<?php
/**
 * Created by ra on 6/13/2015.
 */

//single images
td_demo_media::add_image_to_media_gallery('td_pic_infinite1',                "http://demo_content.tagdiv.com/ion_mag/default/infinite1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_infinite2',                "http://demo_content.tagdiv.com/ion_mag/default/infinite2.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_infinite3',                "http://demo_content.tagdiv.com/ion_mag/default/infinite3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_infinite4',                "http://demo_content.tagdiv.com/ion_mag/default/infinite4.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_infinite5',                "http://demo_content.tagdiv.com/ion_mag/default/infinite5.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_infinite6',                "http://demo_content.tagdiv.com/ion_mag/default/infinite6.jpg");