<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/ion_mag/default/p3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p4',                  "http://demo_content.tagdiv.com/ion_mag/default/p4.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p5',                  "http://demo_content.tagdiv.com/ion_mag/default/p5.jpg");

//ads
td_demo_media::add_image_to_media_gallery('td_header_ad',               "http://demo_content.tagdiv.com/ion_mag/default/ad_header.png");
td_demo_media::add_image_to_media_gallery('td_content_ad',              "http://demo_content.tagdiv.com/ion_mag/default/ad_content.jpg");
td_demo_media::add_image_to_media_gallery('td_sidebar_ad',              "http://demo_content.tagdiv.com/ion_mag/default/ad_sidebar.jpg");
td_demo_media::add_image_to_media_gallery('td_big_ad',                  "http://demo_content.tagdiv.com/ion_mag/default/ad_big.png");