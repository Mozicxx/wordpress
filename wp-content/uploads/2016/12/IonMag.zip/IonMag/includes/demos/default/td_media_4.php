<?php
/**
 * Created by ra on 6/13/2015.
 */

//logo
td_demo_media::add_image_to_media_gallery('td_pic_logo_header',               "http://demo_content.tagdiv.com/ion_mag/default/logo_header.png");
td_demo_media::add_image_to_media_gallery('td_pic_logo_footer',               "http://demo_content.tagdiv.com/ion_mag/default/logo_footer.png");

//footer bg
td_demo_media::add_image_to_media_gallery('td_pic_footer_bg',              "http://demo_content.tagdiv.com/ion_mag/default/footer_bg.jpg");

//single images
td_demo_media::add_image_to_media_gallery('td_pic_homepage',            "http://demo_content.tagdiv.com/ion_mag/default/homepage.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_blog',                "http://demo_content.tagdiv.com/ion_mag/default/blog.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_fashion',             "http://demo_content.tagdiv.com/ion_mag/default/fashion.jpg");